/*global $:false */

jQuery(document).ready(function($){'use strict';
	$("a[data-rel]").prettyPhoto();
});